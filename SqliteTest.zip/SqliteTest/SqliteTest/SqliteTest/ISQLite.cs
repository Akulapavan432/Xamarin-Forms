﻿using SQLite.Net;
using System;
using System.Collections.Generic;
using System.Text;

namespace SqliteTest
{
  public  interface ISQLite
  {
        SQLiteConnection GetConnection();
  }
}
