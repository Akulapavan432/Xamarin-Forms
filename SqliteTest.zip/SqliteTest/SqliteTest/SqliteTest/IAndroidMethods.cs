﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqliteTest
{
   public interface IAndroidMethods
    {
        void CloseApp();
    }
}
