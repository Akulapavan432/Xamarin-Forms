﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SqliteTest.Models
{
    public class Contacts
    {
        public string Name { get; set; }
        public string Num { get; set; }
        public string imgsource { get; set; }
    }
}
