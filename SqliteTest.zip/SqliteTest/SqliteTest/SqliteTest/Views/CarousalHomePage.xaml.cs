﻿using SqliteTest.ViewModels;
using System;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SqliteTest.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CarousalHomePage : CarouselPage
    {
        public RegistrationViewModel _registrationViewModel;
        public string gender;
        public CarousalHomePage()
        {
            InitializeComponent();
            _registrationViewModel = new RegistrationViewModel();
            GenderPicker.Items.Add("Male");
            GenderPicker.Items.Add("Female");
            GenderPicker.SelectedIndexChanged += GenderPicker_SelectedIndexChanged;
            Date.SetValue(DatePicker.MinimumDateProperty, DateTime.Now.AddHours(-876000)); //Minimum Date 100 Years
            Date.SetValue(DatePicker.MaximumDateProperty, DateTime.Now.AddHours(-8760));  //Maximum Date  1 Years

        }
        void Cancel_Clicked(object sender, System.EventArgs e)
        {
            App.Current.MainPage = new NavigationPage(new LoginPage());
        }
        void RegCancel_Clicked(object sender, System.EventArgs e)
        {
            App.Current.MainPage = new NavigationPage(new LoginPage());
        }
        public string _dateSelected = "";

        private void OnDate_Selected(object sender, DateChangedEventArgs e)
        {
            _dateSelected = e.NewDate.ToString();
        }

        private void GenderPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            gender = GenderPicker.Items[GenderPicker.SelectedIndex].ToString();
        }

        private void Next_Clicked()
        {
            if (NextValidate())
            {
                int num = Children.IndexOf(CurrentPage);

                if (num < Children.Count - 1)
                {
                    int index = num + 1;
                    SelectedItem = Children.ElementAt(index);
                }
            }
        }
        private void Back_Clicked()
        {
            int num = Children.IndexOf(CurrentPage);

            if (num < Children.Count + 1)
            {
                int index = num - 1;
                SelectedItem = Children.ElementAt(index);
            }
        }
        private bool NextValidate()
        {
            string Fname = txtFirstName.Text;
            string Sname = txtSecondName.Text;
            string Dob = _dateSelected;
            string Gender = gender;


            if (string.IsNullOrEmpty(Fname))
            {
                DisplayAlert("User", "Please enter First Name", "OK");
                txtFirstName.Focus();
                return false;
            }
            if (Fname != null)
            {
                if (Fname.Length < 2)
                {
                    DisplayAlert("User", "Please enter more than two characters for First Name", "OK");
                    txtFirstName.Focus();
                    return false;
                }

            }
            if (string.IsNullOrEmpty(Dob))
            {
                DisplayAlert("User", "Please Select Date of Birth", "OK");
                //Date.Focus();
                return false;

            }
            if (string.IsNullOrEmpty(Gender))
            {
                DisplayAlert("Gender", "Please Select Gender", "OK");
                //  GenderPicker.Focus();
                return false;
            }


            return true;
        }
        private bool RegValidate()
        {
            string Emailid = txtEmailAddress.Text;
            string Password = txtregPassword.Text;
            string ConfirmPassword = txtConfirmPassword.Text;
                      
            if (!ValidateEmail(Emailid))
            {
                DisplayAlert("", "Please enter valid email", "Ok");
                txtEmailAddress.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(Password))
            {
                DisplayAlert("User", "Please enter the Password ", "Ok");
                txtregPassword.Focus();
                return false;

            }
            if (string.IsNullOrEmpty(ConfirmPassword))
            {
                DisplayAlert("User", "Please enter the ConfirmPassword ", "Ok");
                txtConfirmPassword.Focus();
                return false;

            }
            //if (txtConfirmPassword.Text.Equals(txtregPassword.Text))
            //{
            //    DisplayAlert("User", "Password not matching", "Ok");
            //    txtConfirmPassword.Focus();
            //    return false;
            //}

            return true;
        }

        private async void Submit_Clicked(object s, EventArgs e)
        {
            if (NextValidate())
            {
                if (RegValidate())
                {
                    try
                    {
                        //_registrationViewModel.FirstName = txtFirstName.Text;
                        //_registrationViewModel.SecondName = txtSecondName.Text;
                        ////_registrationViewModel.DateOfBirth = _dateSelected;
                        //_registrationViewModel.Gender = gender;
                        //_registrationViewModel.EmailAddress = txtEmailAddress.Text;
                        //_registrationViewModel.Password = txtregPassword.Text;
                        if (txtConfirmPassword.Text.Equals(txtregPassword.Text))
                        {
                            int res = _registrationViewModel.SaveUserData(new Models.RegistrationModel
                            {
                                FirstName = txtFirstName.Text,
                                SecondName = txtSecondName.Text,
                                DateOfBirth = _dateSelected,
                                Gender = gender,
                                EmailAddress = txtEmailAddress.Text,
                                Password = txtregPassword.Text
                            });
                            if (res == 1)
                            {
                                await DisplayAlert("Registration", "Successfully completed", "ok");
                                await Navigation.PushAsync(new LoginPage());
                            }
                            //else
                            //{
                            //    await DisplayAlert("beep beep", "Error Registering User. Please try again", "ok");
                            //}
                        }
                        else
                        {
                            await DisplayAlert("User", "Password didnot match", "ok");
                            txtConfirmPassword.Focus();

                        }

                    }

                    catch (Exception ex)
                    {

                        Debug.WriteLine(ex.ToString());

                    }

                }
            }

        }
        private bool ValidateEmail(string email)
        {
            if (email != null)
            {
                bool isEmail = Regex.IsMatch(email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
                return isEmail;
            }
            else
            {
                return false;
            }
        }



       

        //private async void OnTestClicked(object s, EventArgs e)
        //{
        //    try
        //    {
        //        var res = _registrationViewModel.GetUserData();
        //    }
        //    catch (Exception ex)
        //    {

        //        Debug.WriteLine(ex.StackTrace);
        //    }
        //}



    }
}