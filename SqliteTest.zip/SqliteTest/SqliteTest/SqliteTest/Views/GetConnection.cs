﻿using System;

namespace SqliteTest.Views
{
    internal class GetConnection
    {
        private string dpPath;

        public GetConnection(string dpPath)
        {
            this.dpPath = dpPath;
        }

        internal object Table<T>()
        {
            throw new NotImplementedException();
        }
    }
}