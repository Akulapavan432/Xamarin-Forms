﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SqliteTest.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ForgotPassword : ContentPage
	{
		public ForgotPassword ()
		{
			InitializeComponent ();
		}
        private async void Cancel_Clicked(object s, EventArgs e)
        {
            await Navigation.PushAsync(new LoginPage());
        }
        private async void Submit_Clicked(object s, EventArgs e)
        {
            await Navigation.PushAsync(new LoginPage());
        }
        public string _dateSelected = "";
        private void OnDate_Selected(object sender, DateChangedEventArgs e)
        {
            _dateSelected = e.NewDate.ToString();
        }
        //private void radioButtonMail_Clicked (object sender, EventArgs e)
        //{
           
        //     radioButton.Source = ("radioBtn.png");

        //    radioButton.IsVisible = true;
        //   // radioButton.IsVisible = false;

        //}
        //private void radioButtonFemail_Clicked(object sender, EventArgs e)
        //{
        //    radioButtonFemail.Source = "unRadioBtn.png";
        //    // radioButtonFemail.IsVisible = false;
        //    //radioButtonFemail.IsVisible = true;
        //    radioButtonFemail.IsVisible = false;
        //}
        //public void RadioButton1_CheckedChanged(object sender, EventArgs e)
        //{
        //    Label1.Text = "You selected Radio Button " + RadioButton1.Text;
        //}


    }
}