﻿using SqliteTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SqliteTest.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class HomePage : ContentPage
    {
        public List<Contacts> tempdata;
        public HomePage ()
		{

			InitializeComponent ();
            data();
            list.ItemsSource = tempdata;
        }
        //public void Logout_Clicked(object sender, System.EventArgs e)
        // {
        //     App.Current.MainPage = new LoginPage();

        // }
        //Android Physical Back button 
        protected override bool OnBackButtonPressed()
        {
            if (Device.OS == TargetPlatform.Android)
                DependencyService.Get<IAndroidMethods>().CloseApp();

            return base.OnBackButtonPressed();
        }
         public void data()  
        {  
            // all the temp data  
            tempdata = new List<Contacts> {  
                new Contacts(){ Name = "umair", Num = "2323423"},  
                new Contacts(){ Name = "saleh", Num = "23423"},  
                new Contacts(){ Name = "umair", Num = "233423423"},  
                new Contacts(){ Name = "sanat", Num = "2423"},  
                new Contacts(){ Name = "jawad", Num = "323423"},  
                new Contacts(){ Name = "shan", Num = "2323423"},  
                new Contacts(){ Name = "ahmed", Num = "2323423"},  
                new Contacts(){ Name = "abc", Num = "2323423"},  
                new Contacts(){ Name = "umair", Num = "2323423"},  
                new Contacts(){ Name = "etc", Num = "2323423"},  
            };  
        }  
  
        private void SearchBar_TextChanged(object sender, TextChangedEventArgs e)  
        {  
            //thats all you need to make a search  
  
            if (string.IsNullOrEmpty(e.NewTextValue))  
            {  
                list.IsVisible=false;  
            }  
  
            else  
            {  
                list.ItemsSource = tempdata.Where(x => x.Name.StartsWith(e.NewTextValue));  
            }  
        }  
        public async Task RotateImageContinously()
        {
            while (true) 
            {              
                // await image.RotateTo(1 * (360/ 1), 10000, Easing.CubicInOut);
                await image.FadeTo(0, 5000);
                await image.FadeTo(1, 100);
               
            }
        }
        void Testclicked(object sender, EventArgs e)
        {
            App.Current.MainPage = new Firstpage();
        }
    }
}