﻿using SQLite.Net;
using SqliteTest.Models;
using SqliteTest.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SqliteTest.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginPage : CarouselPage
    {
        public RegistrationViewModel _registrationViewModel;
        public LoginPage ()
		{
			InitializeComponent ();
            _registrationViewModel = new RegistrationViewModel();
            RotateImageContinously();
        }
        private async void Forgot_Clicked(object s, EventArgs e)
        {
            
            await Navigation.PushAsync(new  ForgotPassword());
        }
        private async void Reg_Clicked(object s, EventArgs e)
        {
            //await btnRegistration.TranslateTo(-Application.Current.MainPage.Width, 0, 150, Easing.Linear);
            //await btnRegistration.TranslateTo(0, 0, 150, Easing.Linear);
            await Navigation.PushAsync(new CarousalHomePage());
        }

        private async void Login_Clicked(object s, EventArgs e)
        {
            if (Validate())
            {
                // complete Registration process

                try
                {
                    var res = _registrationViewModel.GetUserData();

                    //string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "user.db3"); //Call Database  
                    //var db = new GetConnection(dpPath);
                    //var data = db.Table<RegistrationModel>(); //Call Table  
                    var data1 = res.Where(x => x.EmailAddress == usernameEntry.Text && x.Password == passwordEntry.Text).FirstOrDefault(); //Linq Query  
                    if (data1 != null)
                    {
                        await DisplayAlert("Login", "Success", "Ok");
                        await Navigation.PushAsync(new HomePage());

                    }
                    else
                    {
                        await DisplayAlert("Login", "Username and Password is rong!", "Ok");
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.ToString());
                }

            }
        }
        private bool Validate()
        {
            var Email = usernameEntry.Text;
            var Password = passwordEntry.Text;

            var res = _registrationViewModel.GetUserData();
           
            if (string.IsNullOrEmpty(usernameEntry.Text))
            {
                DisplayAlert("User", "Please enter Email Address", "OK");
                usernameEntry.Focus();
                return false;
            }
                if (Email != null)
                {
                    var data1 = res.Where(x => x.EmailAddress == usernameEntry.Text).FirstOrDefault(); //Linq Query  
                    if (data1 == null)
                    {
                        DisplayAlert("User", "Please enter a valid Email Address", "OK");
                    usernameEntry.Focus();
                    return false;
                    }
                }
               
            
            if (string.IsNullOrEmpty(passwordEntry.Text))
            {
                DisplayAlert("User", "Please enter Password", "OK");
                passwordEntry.Focus();
                return false;
            }
            if (Email != null)
            {
                var data1 = res.Where(x => x.Password == passwordEntry.Text).FirstOrDefault(); //Linq Query  
                if (data1 == null)
                {
                    DisplayAlert("User", "Please enter a valid password", "OK");
                    passwordEntry.Focus();
                    return false;
                }
            }
            return true;
        }
        public async Task RotateImageContinously()
        {
            while (true) 
            {              
                // await image.RotateTo(1 * (360/ 1), 10000, Easing.CubicInOut);
                await image.FadeTo(0, 5000);
                await image.FadeTo(1, 100);
               
            }
        }


    }
}