﻿using SqliteTest.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace SqliteTest.ViewModels
{
   public class BaseViewModel
    {
        DataAccess _database;
        public BaseViewModel()
        {
            _database = new DataAccess();
        }
    }
}
