﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SqliteTest;
using SqliteTest.Droid.DependencyServices;

[assembly: Xamarin.Forms.Dependency(typeof(AndroidMethods))]

namespace SqliteTest.Droid.DependencyServices
{
    public class AndroidMethods : IAndroidMethods
    {
        public void CloseApp()
        {
            Android.OS.Process.KillProcess(Android.OS.Process.MyPid());
        }
    }
}